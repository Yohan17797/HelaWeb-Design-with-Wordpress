<?php

namespace YoastSEO_Vendor\GuzzleHttp\Exception;

/**
 * Exception when a server error is encountered (5xx codes)
 */
class ServerException extends \YoastSEO_Vendor\GuzzleHttp\Exception\BadResponseException
{
}
