<?php
/**
 * Template Preset Class
 *
 * @package TotalPoll/Classes/Template_Preset
 * @since   3.0.0
 */
if ( defined( 'ABSPATH' ) === false ) :
	exit;
endif; // Shhh

if ( ! class_exists( 'TP_Template_Preset' ) ) :

	class TP_Template_Preset {

		public function __construct() {
		}

		function remove() {

		}

		function enqueue() {

		}

		function compile() {

		}

	}


endif;
