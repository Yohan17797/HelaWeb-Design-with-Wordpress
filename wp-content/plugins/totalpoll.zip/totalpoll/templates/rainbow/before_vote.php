<?php
if ( defined( 'ABSPATH' ) === false ) :
	exit;
endif; // Shhh
?>

<?php echo $this->poll->settings( 'screens', 'before_vote', 'content' ); ?>