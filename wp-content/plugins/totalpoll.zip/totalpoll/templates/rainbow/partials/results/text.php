<?php
if ( defined( 'ABSPATH' ) === false ) :
	exit;
endif; // Shhh
?>

<br>
<span class="totalpoll-result-text"><?php echo $this->votes($choice); ?></span>