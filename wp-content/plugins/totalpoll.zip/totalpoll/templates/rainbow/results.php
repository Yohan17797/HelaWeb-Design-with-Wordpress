<?php
if ( defined( 'ABSPATH' ) === false ) :
	exit;
endif; // Shhh
?>

<?php include 'partials/question.php'; ?>
<?php include 'partials/results/choices.php'; ?>
