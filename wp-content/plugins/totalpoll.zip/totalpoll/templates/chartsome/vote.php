<?php
if ( defined( 'ABSPATH' ) === false ) :
	exit;
endif; // Shhh
?>
<?php include 'partials/shared/errors.php'; ?>
<?php include 'partials/shared/question.php'; ?>
<?php include 'partials/choices.php'; ?>
<?php include 'partials/shared/fields.php'; ?>
